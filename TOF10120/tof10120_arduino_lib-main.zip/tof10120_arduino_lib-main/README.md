# Readme

Arduino library for the TOF10120 Time-of-Flight ranging sensor.

Should work with most Arduino, ESP32 and ESP8266 boards. The code is based on the
[Supplier documentation for the TOF10120](https://www.makerguides.com/wp-content/uploads/2024/09/TOF10120-supplier-doc.zip)

For more details see 
[TOF10120 Distance Sensor with Arduino](https://www.makerguides.com/tof10120-distance-sensor-with-arduino/)

## Packaging

Just zip up all the contents as zip file or download this repository as a .zip from GitHub via
`Code -> Download ZIP`

## Using library

In Arduino IDE menu, go to `Sketch -> Include Libray -> Add .ZIP Library...` and then select the zipped library.

After including it, you can add the include headers to your current sketch with `Sketch -> Include Library -> TOF10120`.

## Running examples

You can open the example from the Arduino IDE by going to the menu `File -> Examples -> TOF10120 -> TOF10120_test`.

## Example 

A simple example that includes the library and uses the distance() function 
to print the distance measured by the TOF10120 sensor to the Serial Monitor.

The code assumes that pin 6 (SCL) and  pin 5 (SDA) of the TOF10120 
are connected to the standard SCL and SDA pins of the micrcontroller.
However, you can use `sensor.init(sda, scl)` to set specific pins, e.g.
for software I2C on ESP32 and ESP8266 boards.

```
#include "TOF10120.h"

TOF10120 sensor = TOF10120();

void setup() {
  Serial.begin(9600);
  sensor.init();
}

void loop() {
  Serial.println(sensor.distance());
  delay(100);
}
```